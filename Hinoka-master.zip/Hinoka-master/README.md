# Hinoka
Discord Bot for Weeblet Server

Created for entertainment/wiki stuff
