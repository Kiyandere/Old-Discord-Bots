package com.weebletflowers.hinoka.Games;
import com.jagrosh.jdautilities.command.Command;
import com.jagrosh.jdautilities.command.CommandEvent;
public class GameList extends Command
{
    public GameList()
    {
        this.name = "Game";
        this.aliases = new String[]{"GameList"};
        this.help = "Show a list of available game";
        this.hidden = true; //TODO: Change later to false
        this.children = new Command[]{new TicTacToe()};
    }

    @Override
    protected void execute(CommandEvent event)
    {

    }

}
