package com.weebletflowers.hinoka.Games;
import com.jagrosh.jdautilities.command.Command;
import com.jagrosh.jdautilities.command.CommandEvent;
public class TicTacToe extends Command
{
    public TicTacToe()
    {
        this.name = "TicTacToe";
        this.hidden = true;


    }

    @Override
    protected void execute(CommandEvent event)
    {

    }

}
