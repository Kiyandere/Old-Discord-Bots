package com.weebletflowers.hinoka.NewMember;

import com.jagrosh.jdautilities.command.Command;
import com.jagrosh.jdautilities.command.CommandEvent;
import com.jagrosh.jdautilities.commons.utils.FinderUtil;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.entities.TextChannel;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import java.util.List;
import java.util.Random;

//only Tsukika can call this
public class Join extends ListenerAdapter //Command
{
    public void onGuildMessageReceived(GuildMessageReceivedEvent event)
    {
        String[] command = event.getMessage().getContentRaw().split("\\s+");

        if(event.getAuthor().isBot())
        {
            if (command[0].equalsIgnoreCase("=allyou"));
            {
                try
                {
                    TextChannel mainChat = event.getGuild()
                            .getTextChannelsByName("chill-chat", true).get(0);

                    long userID = Long.parseLong(command[1]);
                    Member newMember = event.getGuild().getMemberById(userID);
                    mainChat.sendMessage("Welcome " + newMember.getAsMention() + "! Enjoy your stay!").complete();
                    event.getMessage().delete().complete();
                }
                catch (Exception e)
                {
                    //do nothing
                }

            }
        }


    }

//    public Join()
//    {
//        this.name = "allyou";
//        this.hidden = true;
//        this.requiredRole = "Flower Sisters";
//    }
//    @Override
//    protected void execute(CommandEvent event)
//    {
//        if (event.getAuthor().isBot())
//        {
//            if (event.getChannel().getName().equalsIgnoreCase("new-members"))
//            {
//                long user = event.getAuthor().getIdLong();
//                event.getMessage().delete().complete();
//
//                //Add Seedlet
//                List<Role> found = FinderUtil.findRoles("Weeblet Seedlet", event.getGuild());
//                Role role = found.get(0);
//                event.getGuild().addRoleToMember(user, role).complete();
//
//                //open Chill-Chat
//                TextChannel mainChat = event.getGuild()
//                        .getTextChannelsByName("chill-chat", true).get(0);
//
//                mainChat.sendMessage("Welcome " + event.getAuthor().getAsMention() + "! Enjoy your stay!").complete();
//            }
//            else
//            {
//                event.getMessage().delete().complete();
//            }
//        }
//        else
//        {
//            event.getMessage().delete().complete();
//        }
//    }
}
