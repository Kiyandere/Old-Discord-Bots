# Weebie
Discord Bot for The Weeblet server

@Author Dnguyen0707
