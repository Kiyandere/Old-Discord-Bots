import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent;

public class AdminCommands extends Commands
{
    @Override
    public void onGuildMessageReceived(GuildMessageReceivedEvent event)
    {
        String[] args = event.getMessage().getContentRaw().split("\\s+");
        //TODO make it so that this is for admin only

        //TODO make it do something else
        if (args[0].equalsIgnoreCase(main.prefix + "test"))
        {

        }
    }
}
