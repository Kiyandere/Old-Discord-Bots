import com.sedmelluq.discord.lavaplayer.player.AudioPlayer;
import com.sedmelluq.discord.lavaplayer.track.playback.MutableAudioFrame;

import java.nio.Buffer;
import java.nio.ByteBuffer;
public class AudioSendHandler implements net.dv8tion.jda.api.audio.AudioSendHandler
{
    private final AudioPlayer audioPlayer;
    private final MutableAudioFrame lastFrame;
    private final ByteBuffer buffer;

    public AudioSendHandler(AudioPlayer audioPlayer)
    {
        this.audioPlayer = audioPlayer;
        this.buffer = ByteBuffer.allocate(1024);
        this.lastFrame = new MutableAudioFrame();
        this.lastFrame.setBuffer(buffer);
    }

    @Override
    public boolean canProvide()
    {
        return audioPlayer.provide(lastFrame);
    }

    @Override
    public ByteBuffer provide20MsAudio()
    {
        ((Buffer) buffer).flip();

        return buffer;
    }

    @Override
    public boolean isOpus()
    {
        return true;
    }

}
