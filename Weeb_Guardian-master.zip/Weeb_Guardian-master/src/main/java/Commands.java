import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class Commands extends ListenerAdapter
{
    //Main Commands
    public void onGuildMessageReceived(GuildMessageReceivedEvent event)
    {
        String[] command = event.getMessage().getContentRaw().split("\\s+");

        //Character database
        if (command[0].equalsIgnoreCase(main.prefix + "character"))
        {
            //check if they have more than one word
            if (command.length == 2)
            {
                if (command[1].equalsIgnoreCase("sinoalice"))
                {
                    event.getChannel().sendMessage(
                            "https://sinoalice.game-db.tw/characters").queue();
                }
                else if (command[1].equalsIgnoreCase("azurlane"))
                {
                    event.getChannel().sendMessage(
                            "https://azurlane.koumakan.jp/List_of_Ships_by_Image")
                            .queue();
                }
                else if (command[1].equalsIgnoreCase("arknights"))
                {
                    event.getChannel().sendMessage(
                            "https://gamepress.gg/arknights/tools/interactive-operator-list#tags=null##stats")
                            .queue();
                }
                else if (command[1].equalsIgnoreCase("honkaiimpact"))
                {
                    event.getChannel().sendMessage(
                            "https://honkaiimpact3.gamepedia.com/Valkyries")
                            .queue();
                }
                else
                {
                    event.getChannel().sendMessage(
                            "I don't understand what you're typing, please try again")
                            .queue();
                }
            }
            else
            {
                //send the list of what they should type
                event.getChannel().sendMessage(
                        "**Please type the game listed after //character**\n" +
                                "sinoalice, azurlane, arknights, honkaiimpact")
                        .queue();
            }
        }
    }

}
