
import net.dv8tion.jda.api.entities.*;
import net.dv8tion.jda.api.events.guild.member.GuildMemberJoinEvent;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import java.util.Random;


public class GuildStuff extends ListenerAdapter
{
    private String[] messages = {
            "[member] joined, go and compliment their hair",
            "Yahallo [member]! Welcome to the Weeblet",
            "It's not like we need you here [member], b-baka!",
            "You think it was a bot, but it was me, [member]",
            "My current being is due to [member]'s presence",
            "To suffer at the hands of [member] is my ideal",
            "[member] joined the fleet, get ready for sorties",
            "[member] is the new operator that join us today",
            "[member] is the new valkyries, time to fight!"
    };

    //automatically give bot roles
    public void onGuildMemberJoin(GuildMemberJoinEvent event)
    {
        if (event.getMember().getUser().isBot())
        {
            Guild guild = event.getGuild();
            Role slave = guild.getRoleById("745846190897102909");
            Role weebs = guild.getRoleById("745165918056742912");
            guild.addRoleToMember(event.getMember(), weebs).complete();
            guild.addRoleToMember(event.getMember(), slave).complete();
        }
    }

    public void onMessageReceived(MessageReceivedEvent event)
    {
        Guild guild = event.getGuild();
        Role weebs = guild.getRoleById("745165918056742912");
        Member member = event.getMember();
        String[] args = event.getMessage().getContentRaw().split("\\s+");

        Random rand = new Random();
        int number = rand.nextInt(messages.length);

        GuildChannel channel = guild.getGuildChannelById("752408444165685298");

        //make sure in the right channel
        if (event.getChannel().equals(channel))
        {
            //get role
            if (args[0].equalsIgnoreCase(main.prefix + "yahallo"))
            {
                event.getMessage().delete().complete();
                guild.addRoleToMember(event.getMember(), weebs).complete();

                event.getChannel().sendMessage(messages[number]
                        .replace("[member]", member.getAsMention())).queue();
            }
        }
    }

}
