import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent;

import java.util.Random;
public class InteractionCommands extends Commands
{
    @Override
    public void onGuildMessageReceived(GuildMessageReceivedEvent event)
    {
        String[] command = event.getMessage().getContentRaw().split("\\s+");
        Random rand = new Random();

        //highfive
        if (command[0].equalsIgnoreCase(main.prefix + "highfive"))
        {
            String[] highfive = {
                    "https://tenor.com/view/anime-high-five-love-gif-10559431",
                    "https://tenor.com/view/anime-manga-japanese-anime-japanese-manga-seven-deadly-sins-gif-5374033",
                    "https://tenor.com/view/anime-hinata-nishioya-haikyuu-friends-gif-5682921",
                    "https://tenor.com/view/hunter-xhunter-high-five-killua-zoldyck-gon-freecss-anime-gif-16129960",
                    "https://tenor.com/view/fairy-tail-nalu-natsu-lucy-gif-9443275",
                    "https://tenor.com/view/yes-high-five-smile-happy-no-game-no-life-gif-17337454",
                    "https://tenor.com/view/fairytail-wink-high-five-anime-gif-4746486"
            };
            int number = rand.nextInt(highfive.length);
            event.getChannel().sendMessage(highfive[number]).queue();
        }
        //headpat
        else if (command[0].equalsIgnoreCase(main.prefix + "headpat"))
        {
            String[] headpat = {
                    "https://tenor.com/view/anime-head-pat-anime-head-rub-neko-anime-love-anime-gif-16121044",
                    "https://tenor.com/view/kaede-azusagawa-kaede-gif-head-headpat-gif-13284057",
                    "https://tenor.com/view/anime-head-rub-head-pat-pat-rub-gif-16085328",
                    "https://tenor.com/view/pat-head-pat-gif-12018807",
                    "https://tenor.com/view/anime-anime-couple-anime-head-pat-anime-funny-anime-blush-gif-16085272",
                    "https://tenor.com/view/kyo-ani-musaigen-phantomworld-izumi-anime-gif-4977531",
                    "https://tenor.com/view/black-hanekawa-monogatari-anime-pat-head-gif-16508807"
            };
            int number = rand.nextInt(headpat.length);
            event.getChannel().sendMessage(headpat[number]).queue();

        }
        //goodmorning
        else if (command[0].equalsIgnoreCase(main.prefix + "goodmorning"))
        {
            String[] morning = {
                    "Good morning to you, [member]",
                    "Hope you have a great day [member]",
                    "Have you eaten breakfast yet [member]?",
                    "I had a great time last night [member] :)",
                    "G-good morning, b-baka [member]",
                    "So you're alive [member]"
            };
            int number = rand.nextInt(morning.length);
            event.getChannel().sendMessage(morning[number]
                    .replace("[member]", event.getAuthor().getAsMention()))
                    .queue();

        }
        //goodnight
        else if (command[0].equalsIgnoreCase(main.prefix + "goodnight"))
        {
            String[] night = {
                    "Good night to you, [member]",
                    "Hope you have a great sleep [member]",
                    "I ain't letting you sleep tonight [member] :)",
                    "Sleep tight [member]",
                    "I don't need your good night, b-baka [member]",
                    "Try not to lewd me at night [member]"
            };
            int number = rand.nextInt(night.length);
            event.getChannel().sendMessage(night[number]
                    .replace("[member]", event.getAuthor().getAsMention()))
                    .queue();
        }
        //lammy
        else if (command[0].equalsIgnoreCase(main.prefix + "lammy"))
        {
            event.getChannel().sendMessage("http://gph.is/17xZq0H").queue();
        }
        //about me
        else if (command[0].equalsIgnoreCase(main.prefix + "about"))
        {
            String message =
                    "I was created by the owner himself because that man was bored as shit one day and literally made me on impulse, and haven't touch me once until he made the SINoAlice guild. " +
                            "So far I can only do basic commands and stuff but that's not the point. " +
                            "Despite being a custom made, I aim to become your favorite bot :)" +
                            "\n \n" +
                            "Also the owner is a terrible programmer, he only program when he feels like it." +
                            "\n" +
                            "I was coded using Java";

            String embed = "**Favorite color:** Red\n" +
                    "**Favorite food:** Pho, Ramen and Biryani\n" +
                    "**Favorite Anime:** Oregairu, Aobuta, and Monogatari Series\n" +
                    "**Favorite music:** J-pop\n" +
                    "**Favorite artist:** Yanagi Nagi, Claris, Yoasobi, YuNi, TUYU\n" +
                    "**Favorite game:** Nier: Automata\n" +
                    "**Favorite hobby:** Sleep lmao";


            EmbedBuilder weebie = new EmbedBuilder();
            weebie.setTitle("About Me");
            weebie.setDescription(embed);


            event.getChannel().sendMessage(message).queue();
            event.getChannel().sendMessage(weebie.build()).queue();
        }
        //Roll
        else if (command[0].equalsIgnoreCase(main.prefix + "Roll"))
        {

            Member other = event.getMessage().getMentionedMembers().get(0);

            int myNum = rand.nextInt(6);
            int otherNum = rand.nextInt(6);

            if (myNum < otherNum)
            {
                event.getChannel().sendMessage(
                        "You got: " + myNum + " while " + other.getAsMention() +
                                " got: " + otherNum + ". You lose.").queue();

            }
            else if (myNum > otherNum)
            {
                event.getChannel().sendMessage(
                        "You got: " + myNum + " while " + other.getAsMention() +
                                "got: " + otherNum + ". You win.").queue();
            }
            else
            {
                event.getChannel().sendMessage(
                        "You got: " + myNum + " while " + other.getAsMention() +
                                " got: " + otherNum + ". It's a tie.").queue();
            }
        }
        //rock paper scissor
        else if (command[0].equalsIgnoreCase(main.prefix + "rps"))
        {
            int num = rand.nextInt(2);
            String userChoice = command[1];
            String botChoice;

            switch (num)
            {
                case 0:
                    botChoice = "rock";
                    break;
                case 1:
                    botChoice = "paper";
                    break;
                case 2:
                    botChoice = "scissor";
                    break;
                default:
                    throw new IllegalStateException("Unexpected value: " + num);
            }

            if (userChoice.equalsIgnoreCase("rock"))
            {
                if (botChoice.equalsIgnoreCase("rock"))
                {
                    event.getChannel().sendMessage("I got rock, we tied")
                            .queue();
                }
                else if (botChoice.equalsIgnoreCase("paper"))
                {
                    event.getChannel().sendMessage("I got paper, I won")
                            .queue();
                }
                else if (botChoice.equalsIgnoreCase("scissor"))
                {
                    event.getChannel().sendMessage("I got scissor, you won")
                            .queue();
                }
            }
            else if (userChoice.equalsIgnoreCase("paper"))
            {
                if (botChoice.equalsIgnoreCase("rock"))
                {
                    event.getChannel().sendMessage("I got rock, you won")
                            .queue();
                }
                else if (botChoice.equalsIgnoreCase("paper"))
                {
                    event.getChannel().sendMessage("I got paper, we tied")
                            .queue();
                }
                else if (botChoice.equalsIgnoreCase("scissor"))
                {
                    event.getChannel().sendMessage("I got scissor, I won")
                            .queue();
                }
            }
            else if (userChoice.equalsIgnoreCase("scissor"))
            {
                if (botChoice.equalsIgnoreCase("rock"))
                {
                    event.getChannel().sendMessage("I got rock, I won").queue();
                }
                else if (botChoice.equalsIgnoreCase("paper"))
                {
                    event.getChannel().sendMessage("I got paper, you won")
                            .queue();
                }
                else if (botChoice.equalsIgnoreCase("scissor"))
                {
                    event.getChannel().sendMessage("I got scissor, we tied")
                            .queue();
                }
            }
        }
        //pun
        else if (command[0].equalsIgnoreCase(main.prefix + "pun"))
        {
            //https://www.reddit.com/r/dadjokes/comments/76jfme/a_giant_list_of_puns/
            String[] pun = {
                    "What do you call a fake noodle? An Impasta.",
                    "I would avoid the sushi if I was you. It's a little fishy.",
                    "Want to hear a joke about paper? Nevermind it's tearable.",
                    "Why did the cookie cry? Because his father was a wafer so long!",
                    "I used to work in a shoe recycling shop. It was sole destroying.",
                    "What do you call a belt with a watch on it? A waist of time.",
                    "How do you organize an outer space party? You planet.",
                    "I went to a seafood disco last week... and pulled a mussel.",
                    "Do you know where you can get chicken broth in bulk? The stock market.",
                    "I cut my finger chopping cheese, but I think that I may have greater problems.",
                    "My cat was just sick on the carpet, I don't think it's feline well.",
                    "Why did the octopus beat the shark in a fight? Because it was well armed.",
                    "How much does a hipster weigh? An instagram.",
                    "What did daddy spider say to baby spider? You spend too much time on the web.",
                    "Atheism is a non-prophet organisation.",
                    "There's a new type of broom out, it's sweeping the nation.",
                    "What cheese can never be yours? Nacho cheese.",
                    "What did the Buffalo say to his little boy when he dropped him off at school? Bison.",
                    "Have you ever heard of a music group called Cellophane? They mostly wrap.",
                    "Why does Superman gets invited to dinners? Because he is a Supperhero.",
                    "How was Rome split in two? With a pair of Ceasars.",
                    "The shovel was a ground breaking invention.",
                    "A scarecrow says, \"This job isn't for everyone, but hay, it's in my jeans.\"",
                    "A Buddhist walks up to a hot dog stand and says, \"Make me one with everything.\"",
                    "Did you hear about the guy who lost the left side of his body? He's alright now.",
                    "What do you call a girl with one leg that's shorter than the other? Ilene.",
                    "I did a theatrical performance on puns. It was a play on words.",
                    "What do you do with a dead chemist? You barium.",
                    "I bet the person who created the door knocker won a Nobel prize.",
                    "Towels can't tell jokes. They have a dry sense of humor.",
                    "Two birds are sitting on a perch and one says \"Do you smell fish?\"",
                    "Do you know sign language? You should learn it, it's pretty handy.",
                    "What do you call a beautiful pumpkin? GOURDgeous.",
                    "Why did one banana spy on the other? Because she was appealing.",
                    "What do you call a cow with no legs? Ground beef.",
                    "What do you call a cow with two legs? Lean beef.",
                    "What do you call a cow with all of its legs? High steaks.",
                    "A cross eyed teacher couldn't control his pupils.",
                    "After the accident, the juggler didn't have the balls to do it.",
                    "I used to be afraid of hurdles, but I got over it.",
                    "To write with a broken pencil is pointless.",
                    "I read a book on anti-gravity. I couldn't put it down.",
                    "I couldn't remember how to throw a boomerang but it came back to me.",
                    "What should you do if you are cold? Stand in the corner. It's 90 degrees.",
                    "How does Moses make coffee? Hebrews it.",
                    "The energizer bunny went to jail. He was charged with battery.",
                    "What did the alien say to the pitcher of water? Take me to your liter.",
                    "What happens when you eat too many spaghettiOs? You have a vowel movement.",
                    "The soldier who survived mustard gas and pepper spray was a seasoned veteran.",
                    "Sausage puns are the wurst.",
                    "What do you call a bear with no teeth? A gummy bear.",
                    "Why shouldn't you trust atoms? They make up everything.",
                    "What's it called when you have too many aliens? Extraterrestrials.",
                    "Want to hear a pizza joke? Nevermind, it's too cheesy.",
                    "What do cows tell each other at bedtime? Dairy tales.",
                    "Why can't you take inventory in Afghanistan? Because of the tally ban.",
                    "Why didn't the lion win the race? Because he was racing a cheetah.",
                    "What happens to nitrogen when the sun comes up? It becomes daytrogen.",
            };

            int num = rand.nextInt(pun.length);
            event.getChannel().sendMessage(pun[num]).queue();

        }
    }

}
