import net.dv8tion.jda.api.events.message.guild.GuildMessageReceivedEvent;
//secret commmands so when user type a certain phrase the bot reply
public class SecretCommands extends Commands
{
    @Override
    public void onGuildMessageReceived(GuildMessageReceivedEvent event)
    {
        String message = event.getMessage().getContentRaw();

        if (message.equalsIgnoreCase("Yui is best girl"))
        {
            event.getChannel().sendMessage("I agree\n" + "https://tenor.com/view/yuigahama-yui-oregairu-yui-yuigahama-cute-gif-13363461").queue();
        }
        else if (message.equalsIgnoreCase("Mai is best girl") || message.equalsIgnoreCase("Mai-san is best girl"))
        {
            event.getChannel().sendMessage("Yes, she is my ideal wife\n" + "https://tenor.com/view/mai-sakurajima-bunny-girl-senpai-anime-selfie-gif-17571525").queue();
        }
        else if (message.equalsIgnoreCase("This bot is stupid") || message.equalsIgnoreCase("bot is dumb"))
        {
            event.getChannel().sendMessage("https://tenor.com/view/reverse-uno-no-you-uno-card-gif-15082640").queue();
        }
    }
}
