import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;

public class SelfRole extends GuildStuff
{
    @Override
    public void onMessageReceived(MessageReceivedEvent event)
    {
        Guild guild = event.getGuild();
        Role PC = guild.getRoleById("751522696332050514");
        Role Mobile = guild.getRoleById("751522967757914245");
        Role Xbox = guild.getRoleById("751522988049825824");
        Role PS = guild.getRoleById("751523004856533022");
        Role Switch = guild.getRoleById("751523020312412170");
        Role Watcher = guild.getRoleById("755557833185165473");
        Role Reader = guild.getRoleById("755557836079235264");

        String[] args = event.getMessage().getContentRaw().split("\\s+");

        //not bot
        if(!event.getAuthor().isBot())
        {
            //get role
            if (args[0].equalsIgnoreCase(main.prefix + "PC"))
            {
                guild.addRoleToMember(event.getMember(), PC).complete();
                event.getChannel().sendMessage("Got chu " + event.getMember().getAsMention()).queue();
            }
            else if (args[0].equalsIgnoreCase(main.prefix + "mobile"))
            {
                guild.addRoleToMember(event.getMember(), Mobile).complete();
                event.getChannel().sendMessage("Got chu " + event.getMember().getAsMention()).queue();
            }
            else if (args[0].equalsIgnoreCase(main.prefix + "xbox"))
            {
                guild.addRoleToMember(event.getMember(), Xbox).complete();
                event.getChannel().sendMessage("Got chu " + event.getMember().getAsMention()).queue();
            }
            else if (args[0].equalsIgnoreCase(main.prefix + "PS"))
            {
                guild.addRoleToMember(event.getMember(), PS).complete();
                event.getChannel().sendMessage("Got chu " + event.getMember().getAsMention()).queue();
            }
            else if (args[0].equalsIgnoreCase(main.prefix + "Switch"))
            {
                guild.addRoleToMember(event.getMember(), Switch).complete();
                event.getChannel().sendMessage("Got chu " + event.getMember().getAsMention()).queue();
            }
            else if (args[0].equalsIgnoreCase(main.prefix + "Reader"))
            {
                guild.addRoleToMember(event.getMember(), Reader).complete();
                event.getChannel().sendMessage("Got chu " + event.getMember().getAsMention()).queue();
            }
            else if (args[0].equalsIgnoreCase(main.prefix + "Watcher"))
            {
                guild.addRoleToMember(event.getMember(), Watcher).complete();
                event.getChannel().sendMessage("Got chu " + event.getMember().getAsMention()).queue();
            }
        }
    }
}
