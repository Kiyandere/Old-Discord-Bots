import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.AccountType;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.entities.*;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import javax.security.auth.login.LoginException;
import java.text.ParseException;
import java.util.*;

public class main extends ListenerAdapter
{
    public static JDA jda;
    public static String prefix = "//";

    public static void main(String[] args) throws LoginException
    {
        String token = "NzM5MjA0MTYwMDkxNTg2Njgz.XyXDhQ.a9OfOka5MZXq6F55N7wuhorDWjQ";
        jda = new JDABuilder(AccountType.BOT).setToken(token).build();
        jda.getPresence().setStatus(OnlineStatus.ONLINE);

        //set timer
        Timer timer = new Timer();

        //set what the bot is doing
        TimerTask presence = new TimerTask()
        {
            @Override
            public void run()
            {
                Presence();
            }
        };
        timer.scheduleAtFixedRate(presence, 100, 1800000);

        //reminder for guild war
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 12);
        calendar.set(Calendar.MINUTE, 45);
        Date time = calendar.getTime();
        TimerTask GBtimer = new TimerTask()
        {
            @Override
            public void run()
            {
                TextChannel SAchat = jda.getTextChannelById("739398917363466290");
                Role SArole = jda.getRoleById("739396143636676668");


                SAchat.sendMessage(SArole.getAsMention() + " 15 min until guild battle, get ready!").queue();
            }
        };
        Timer GuildReminder = new Timer();
        GuildReminder.schedule(GBtimer, time);


        //initialing other classes
        jda.addEventListener(new Commands());
        jda.addEventListener(new GuildStuff());
        jda.addEventListener(new AdminCommands());
        jda.addEventListener(new InteractionCommands());
        jda.addEventListener(new SecretCommands());
        jda.addEventListener(new SelfRole());
        jda.addEventListener(new MusicPlayer());
    }

    //set bot presence
    private static void Presence()
    {
        String[] playing = {
                "Nier: Automata",
                "Azur Lane",
                "SINoAlice",
                "Monster Hunter World: Iceborne",
                "Halo: MCC",
                "Minecraft",
                "Code Vein",
                "Azur Lane Crosswave",
                "Soul Worker"
        };

        String[] watching = {
                "Oregairu",
                "The Monogatari Series",
                "Aobuta",
                "Clannad",
                "Konosuba",
                "Violet Evergarden",
                "Steins;Gate",
                "Katanagatari",
                "Mahoutsukai no Yome"
        };

        String[] listening = {
                "Harumodoki - Yanagi Nagi",
                "Megumi no Ame - Yanagi Nagi",
                "Over and Over - Yanagi Nagi",
                "Before My Body Is Dry - Mika Kobayashi feat. David Whitaker",
                "Nier OST: Kaine ~ Salvation",
                "Nier OST: Song of the Ancients / Devola",
                "Nier OST: Song of the Ancients / Popola",
                "Weight of the World - Keiichi Okabe",
                "Shiori - Claris",
                "Kimi no Sei - The Peggies"
        };

        //Initialing Random integer
        Random rand = new Random();
        int num = rand.nextInt(3);

        //Playing
        if (num == 0)
        {
            int play = rand.nextInt(playing.length);
            jda.getPresence().setActivity(Activity.playing(playing[play]));
        }
        //Watching
        else if (num == 1)
        {
            int watch = rand.nextInt(watching.length);
            jda.getPresence().setActivity(Activity.watching(watching[watch]));
        }
        //listening
        else
        {
            int listen = rand.nextInt(listening.length);
            jda.getPresence().setActivity(Activity.listening(listening[listen]));
        }
    }
}
