import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.TextChannel;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

import javax.security.auth.login.LoginException;
import java.util.Calendar;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class main extends ListenerAdapter
{
    public static void main(String[] main) throws LoginException
    {

        JDA jda = JDABuilder.createDefault("OTA5NjE4MDA3NDU2NzUxNjE3.YZG5yA.s1xAPuTZ2d1wixQ68uezXoXN9LY").build();

        //Daily
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 21);
        calendar.set(Calendar.MINUTE, 0);
        Date time = calendar.getTime();
        TimerTask sendEverydayMessage = new TimerTask()
        {
            @Override
            public void run()
            {
                TextChannel muted = jda.getTextChannelById("639242798201044993");

                String dai = "<@346806438783352834> You're a stupid cunt";
                String monis = "<@305834227390480395> Will you stay cute forever?";
                String tommy = "";
                String louis = "";

                muted.sendMessage(dai);
                muted.sendMessage(monis);
            }
        };
        Timer sendEveryday = new Timer();
        sendEveryday.schedule(sendEverydayMessage, time);
    }
}


